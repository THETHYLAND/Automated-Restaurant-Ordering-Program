package restaurant;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Container;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSeparator;
import javax.swing.JTextArea;

public class Kitchen {
	static ServerA sera;
	static ServerB serb;
	static ServerC serc;
	static ServerD serd;
	JTextArea table1order = new JTextArea(5, 5);
	JTextArea table1comments = new JTextArea(5, 5);
	JTextArea table2order = new JTextArea(5, 5);
	JTextArea table2comments = new JTextArea(5, 5);
	JTextArea table3order = new JTextArea(5, 5);
	JTextArea table3comments = new JTextArea(5, 5);
	JTextArea table4order = new JTextArea(5, 5);
	JTextArea table4comments = new JTextArea(5, 5);

	public Kitchen() {
		JFrame frame = new JFrame();
		frame.setTitle("Orders");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel grid = new JPanel(new GridLayout(3, 4));
		JPanel table1but = new JPanel();
		JButton t1_rs = new JButton("Ready Starter");
		JButton t1_rm = new JButton("Ready Main Course");

		JButton t1_rd = new JButton("Ready Dessert");
		table1but.add(t1_rs);
		table1but.add(t1_rm);
		table1but.add(t1_rd);
		ActionListener t1_rsa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sera.rs();
			}
		};
		t1_rs.addActionListener(t1_rsa);
		ActionListener t1_rma = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sera.rm();
			}
		};
		t1_rm.addActionListener(t1_rma);
		ActionListener t1_rda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sera.rd();
			}
		};
		t1_rd.addActionListener(t1_rda);
		///////////////////////////////////////////////////////

		JPanel table2but = new JPanel();
		JButton t2_rs = new JButton("Ready Starter");
		JButton t2_rm = new JButton("Ready Main Course");
		JButton t2_rd = new JButton("Ready Dessert");
		table2but.add(t2_rs);
		table2but.add(t2_rm);
		table2but.add(t2_rd);
		ActionListener t2_rsa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serb.rs();
			}
		};
		t2_rs.addActionListener(t2_rsa);
		ActionListener t2_rma = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serb.rm();
			}
		};
		t2_rm.addActionListener(t2_rma);
		ActionListener t2_rda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serb.rd();
			}
		};
		t2_rd.addActionListener(t2_rda);
		///////////////////////////////////////////////////////

		JPanel table3but = new JPanel();
		JButton t3_rs = new JButton("Ready Starter");
		JButton t3_rm = new JButton("Ready Main Course");
		JButton t3_rd = new JButton("Ready Dessert");
		table3but.add(t3_rs);
		table3but.add(t3_rm);
		table3but.add(t3_rd);
		ActionListener t3_rsa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serc.rs();
			}
		};
		t3_rs.addActionListener(t3_rsa);
		ActionListener t3_rma = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serc.rm();
			}
		};
		t3_rm.addActionListener(t3_rma);
		ActionListener t3_rda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serc.rd();
			}
		};
		t3_rd.addActionListener(t3_rda);
		/////////////////////////////////////////////////////////////////////

		JPanel table4but = new JPanel();
		JButton t4_rs = new JButton("Ready Starter");
		JButton t4_rm = new JButton("Ready Main Course");
		JButton t4_rd = new JButton("Ready Dessert");
		table4but.add(t4_rs);
		table4but.add(t4_rm);
		table4but.add(t4_rd);
		ActionListener t4_rsa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serd.rs();
			}
		};
		t4_rs.addActionListener(t4_rsa);
		ActionListener t4_rma = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serd.rm();
			}
		};
		t4_rm.addActionListener(t4_rma);
		ActionListener t4_rda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serd.rd();
			}
		};
		t4_rd.addActionListener(t4_rda);

		JMenu menu1 = new JMenu("File");

		JMenuItem mNew = new JMenuItem("Kitchen Availability");

		JRadioButtonMenuItem mOpen = new JRadioButtonMenuItem("Open");

		ActionListener openCliked = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sera.kitopen();
				serb.kitopen();
				serc.kitopen();
				serd.kitopen();
			}
		};

		mOpen.addActionListener(openCliked);

		JRadioButtonMenuItem mclosed = new JRadioButtonMenuItem("Closed");

		ActionListener closedCliked = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sera.kitclosed();
				serb.kitclosed();
				serc.kitclosed();
				serd.kitclosed();
			}
		};

		mclosed.addActionListener(closedCliked);
		menu1.add(mNew);
		menu1.add(new JSeparator());
		menu1.add(mOpen);
		menu1.add(mclosed);
		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
		JMenu menu2 = new JMenu("Admin");
		JMenuItem mlogin = new JMenuItem("Login");
		JMenuItem mlogout = new JMenuItem("Logout");
		JMenu mchband = new JMenu("Change Bands");
		JMenuItem mmon = new JMenuItem("Change Monday Band");
		JMenuItem mtues = new JMenuItem("Change Tuesday Band");
		JMenuItem mwed = new JMenuItem("Change Wednesday Band");
		JMenuItem mthurs = new JMenuItem("Change Thursday Band");
		JMenuItem mfri = new JMenuItem("Change Friday Band");
		JMenuItem msat = new JMenuItem("Change Saturday Band");
		JMenuItem msun = new JMenuItem("Change Sunday Band");
		menu2.add(mlogin);
		menu2.add(mlogout);
		mchband.add(mmon);
		mchband.add(mtues);
		mchband.add(mwed);
		mchband.add(mthurs);
		mchband.add(mfri);
		mchband.add(msat);
		mchband.add(msun);
		mlogout.setVisible(false);
		mchband.setVisible(false);
		bar.add(menu2);
		bar.add(mchband);

		ActionListener login1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = "admin";
				String password = "pass";
				String name;
				String pass;
				name = JOptionPane.showInputDialog(null, "Enter User Name", "Login", JOptionPane.INFORMATION_MESSAGE);
				pass = JOptionPane.showInputDialog(null, "Enter Password", "Login", JOptionPane.INFORMATION_MESSAGE);
				if (username.equals(name) && password.equals(pass)) {
					mlogin.setVisible(false);
					mlogout.setVisible(true);
					mchband.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Invalid Details", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		};
		mlogin.addActionListener(login1);
		ActionListener logout1 = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Successfully Logged Out", "Logout",
						JOptionPane.INFORMATION_MESSAGE);
				mlogin.setVisible(true);
				mlogout.setVisible(false);
				mchband.setVisible(false);
			}
		};
		mlogout.addActionListener(logout1);

		ActionListener mona = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Monday's New Band", "Monday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Monday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.monband(name);
					serb.monband(name);
					serc.monband(name);
					serd.monband(name);
				}
			}
		};
		mmon.addActionListener(mona);

		ActionListener tuesa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Tuesday's New Band", "Tuesday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Tuesday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.tuesband(name);
					serb.tuesband(name);
					serc.tuesband(name);
					serd.tuesband(name);
				}
			}
		};
		mtues.addActionListener(tuesa);

		ActionListener weda = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Wednesday's New Band", "Wesnesday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Wednesday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.wedband(name);
					serb.wedband(name);
					serc.wedband(name);
					serd.wedband(name);
				}
			}
		};
		mwed.addActionListener(weda);

		ActionListener thursa = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Thursday's New Band", "Thursday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Thursday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.thursband(name);
					serb.thursband(name);
					serc.thursband(name);
					serd.thursband(name);
				}
			}
		};
		mthurs.addActionListener(thursa);

		ActionListener fria = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Friday's New Band", "Friday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Friday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.friband(name);
					serb.friband(name);
					serb.friband(name);
					serd.friband(name);
				}
			}
		};
		mfri.addActionListener(fria);

		ActionListener sata = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Saturday's New Band", "Saturday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Saturday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.satband(name);
					serb.satband(name);
					serc.satband(name);
					serd.satband(name);
				}
			}
		};
		msat.addActionListener(sata);

		ActionListener suna = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog(null, "Enter Sunday's New Band", "Sunday",
						JOptionPane.INFORMATION_MESSAGE);
				int ans;
				ans = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to change Sunday's band to " + name + " ?", "Are you sure",
						JOptionPane.YES_NO_OPTION);
				if (ans == 0) {
					sera.sunband(name);
					serb.sunband(name);
					serc.sunband(name);
					serd.sunband(name);
				}
			}
		};
		msun.addActionListener(suna);
		ButtonGroup bg = new ButtonGroup();
		bg.add(mOpen);
		bg.add(mclosed);

		frame.setJMenuBar(bar);

		grid.add(table1order);
		grid.add(table2order);
		grid.add(table3order);
		grid.add(table4order);
		grid.add(table1comments);
		grid.add(table2comments);
		grid.add(table3comments);
		grid.add(table4comments);
		grid.add(table1but);
		grid.add(table2but);
		grid.add(table3but);
		grid.add(table4but);
		final CardLayout cards = new CardLayout();
		final JPanel cardz1 = new JPanel();
		cardz1.setLayout(cards);
		cardz1.add(grid, "Kitchen");
		cp.add(cardz1);
		frame.setSize(1300, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void passserA(ServerA serA) {
		sera = serA;
	}

	public static void passserB(ServerB serB) {
		serb = serB;
	}

	public static void passserC(ServerC serC) {
		serc = serC;
	}

	public static void passserD(ServerD serD) {
		serd = serD;
	}

	public void sendTable1(String text, String text2) {
		// TODO Auto-generated method stub
		table1order.setText(text);
		if (text2.equals("Please enter them here!")) {
			table1comments.setVisible(false);
		} else {
			table1comments.setText(text2);
		}
	}

	public void sendTable2(String text, String text2) {
		// TODO Auto-generated method stub
		table2order.setText(text);
		if (text2.equals("Please enter them here!")) {
			table2comments.setVisible(false);
		} else {
			table2comments.setText(text2);
		}
	}

	public void sendTable3(String text, String text2) {
		// TODO Auto-generated method stub
		table3order.setText(text);
		if (text2.equals("Please enter them here!")) {
			table3comments.setVisible(false);
		} else {
			table3comments.setText(text2);
		}
	}

	public void sendTable4(String text, String text2) {
		// TODO Auto-generated method stub
		table4order.setText(text);
		if (text2.equals("Please enter them here!")) {
			table4comments.setVisible(false);
		} else {
			table4comments.setText(text2);
		}
	}

}
